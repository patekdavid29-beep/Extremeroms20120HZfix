#!/system/bin/sh
until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 3
done

sleep 5

# Set persistent properties
setprop persist.sys.sf.high_fps_late_app_default 120
setprop persist.sys.sf.high_fps_early_app_default 120
setprop persist.sys.sf.high_fps_early_gl_default 120
setprop persist.sys.sf.disable_fps_limit 1
setprop persist.sys.sf.hs_mode 1

# Apply settings keys
settings put system peak_refresh_rate 120.0
settings put system min_refresh_rate 120.0
settings put system user_refresh_rate 120
settings put system refresh_rate_mode 1
settings put secure refresh_rate_mode 1
settings put system ms_adaptive_refresh_rate 0
settings put global low_power_refresh_rate 120.0
settings put global refresh_rate_blacklist ""

# Loop daemon to prevent apps like YouTube or GOS from resetting min/peak back to 60.0
while true; do
    CURR_MIN=$(settings get system min_refresh_rate)
    CURR_PEAK=$(settings get system peak_refresh_rate)
    
    if [ "$CURR_MIN" != "120.0" ]; then
        settings put system min_refresh_rate 120.0
    fi
    
    if [ "$CURR_PEAK" != "120.0" ]; then
        settings put system peak_refresh_rate 120.0
    fi
    
    sleep 5
done
